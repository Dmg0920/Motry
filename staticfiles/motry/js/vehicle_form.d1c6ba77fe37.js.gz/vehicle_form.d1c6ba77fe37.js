// Minimal script for vehicle form page
// Keeps production (ManifestStaticFilesStorage) happy when DEBUG=0
// Add behavior here as needed
console.debug('vehicle_form.js loaded');
